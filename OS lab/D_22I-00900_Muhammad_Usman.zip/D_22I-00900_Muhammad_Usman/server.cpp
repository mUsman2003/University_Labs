#include <iostream>
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <cstring>
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <string>
#include <sys/wait.h>
#include <fstream>
#include <ctime>
#include <cstdlib>
#include <sys/select.h>
#include <thread>
#include <vector>
#include <string>

#define RESET   "\033[0m"       
#define BLACK   "\033[30m"      /* Black */
#define RED     "\033[31m"      /* Red */
#define GREEN   "\033[32m"      /* Green */
#define YELLOW  "\033[33m"      /* Yellow */
#define BLUE    "\033[34m"      /* Blue */
#define MAGENTA "\033[35m"      /* Magenta */
#define CYAN    "\033[36m"      /* Cyan */
#define WHITE   "\033[37m"      /* White */

#define BLACK_BG    "\033[40m"      /* Black background */
#define RED_BG      "\033[41m"      /* Red background */
#define GREEN_BG    "\033[42m"      /* Green background */
#define YELLOW_BG   "\033[43m"      /* Yellow background */
#define BLUE_BG     "\033[44m"      /* Blue background */
#define MAGENTA_BG  "\033[45m"      /* Magenta background */
#define CYAN_BG     "\033[46m"      /* Cyan background */
#define WHITE_BG    "\033[47m"      /* White background */

using namespace std;

struct Message 
{
    char sender[256];
    char message[256]; 
};

int main() 
{

    cout << "\033[2J\033[1;1H";

    int users = 0; 

    cout<<"Enter Total Number of Users: ";
    cin>>users;
    cout<<endl<<endl;

    key_t keys[users];
    int shmid[users];
    Message *msgs[users];

    // Generate keys and create shared memory segments
    for (int i = 0; i < users; ++i) 
    {
        keys[i] = ftok("group", i + 1);
        shmid[i] = shmget(keys[i], sizeof(Message), 0666 | IPC_CREAT);
        if (shmid[i] == -1) 
        {
            perror("shmget");
            return 1;
        }
        msgs[i] = (Message *)shmat(shmid[i], (void *)0, 0);
        if (msgs[i] == (void *)-1) 
        {
            perror("shmat");
            return 1;
        }
    }

    cout <<YELLOW << "==================================" << endl;
    cout << "=============ChatVista============" << endl;
    cout << "==================================" <<RESET<< endl << endl;


    while (true) 
    {

        int sender_index,reciver_index;
        cout<<"Enter"<<RED<<" Sender ID"<<RESET<<": ";
        cin>>sender_index;
        cout<<"Enter"<<RED<<" Receiver ID"<<RESET<<": ";
        cin>>reciver_index;

        pid_t pid1 = fork();

        if (pid1 == 0) 
        {
            string str =to_string(reciver_index); 
            char* char_array = new char[str.length()+1];
            for(int i=0;i<str.length();i++)
                char_array[i]=str[i];
            char_array[str.length()]='\0';
            char* args[] = {"./client", char_array, NULL};
            execv("./client", args);
            exit(0);
    
        } 
        else if (pid1 > 0) 
        {
            wait(NULL);
            cout<<endl;
            cout << "(Client "<<RED<<sender_index<<RESET<< " sends a"<<BLUE<<" private "<<RESET<<"message to Client "<<RED<<reciver_index<<RESET<<")"<< endl;
        
            cout <<YELLOW<< "Message: "<<RESET << msgs[reciver_index]->message << endl;
            //memset(msgs[reciver_index], 0, sizeof(Message)); 
            cout<<endl;
        } 
        else 
        {
            cout << "Failed" << endl;
        }
    }

    // Detach from shared memory
    for (int i = 0; i < users; ++i) {
        if (shmdt(msgs[i]) == -1) {
            perror("shmdt");
            return 1;
        }
    }

    // Destroy shared memory segments
    for (int i = 0; i < users; ++i) {
        if (shmctl(shmid[i], IPC_RMID, NULL) == -1) {
            perror("shmctl");
            return 1;
        }
    }

    return 0;
}
