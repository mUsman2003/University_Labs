#include <iostream>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <string>
#include <sys/wait.h>
#include <fstream>
#include <ctime>
#include <cstdlib>
#include <sys/select.h>
#include <ncurses.h>
#include <thread>
#include <chrono>

#define RESET   "\033[0m"       
#define BLACK   "\033[30m"      /* Black */
#define RED     "\033[31m"      /* Red */
#define GREEN   "\033[32m"      /* Green */
#define YELLOW  "\033[33m"      /* Yellow */
#define BLUE    "\033[34m"      /* Blue */
#define MAGENTA "\033[35m"      /* Magenta */
#define CYAN    "\033[36m"      /* Cyan */
#define WHITE   "\033[37m"      /* White */

#define BLACK_BG    "\033[40m"      /* Black background */
#define RED_BG      "\033[41m"      /* Red background */
#define GREEN_BG    "\033[42m"      /* Green background */
#define YELLOW_BG   "\033[43m"      /* Yellow background */
#define BLUE_BG     "\033[44m"      /* Blue background */
#define MAGENTA_BG  "\033[45m"      /* Magenta background */
#define CYAN_BG     "\033[46m"      /* Cyan background */
#define WHITE_BG    "\033[47m"      /* White background */

using namespace std;

char** generateBoard(int n) 
{
    char** board = new char*[n];
    for (int i = 0; i < n; ++i) 
    {
        board[i] = new char[n];
        for (int j = 0; j < n; ++j)
            board[i][j] = '.';
    }

    board[1*n/4][n/2]='A';
    board[3*n/4][n/2]='B';
    return board;
}

void upMovement1(char** board,int n,int &s1)
{
    bool check=true;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) 
        {
            if(i!=0 && board[i-1][j]=='@' && board[i][j]=='A')
                s1+=10;
            else if(i!=0 && board[i-1][j]=='#' && board[i][j]=='A')
                s1+=10;
            else if(i!=0 && board[i-1][j]=='*' && board[i][j]=='A')
                s1+=10;

            if(board[i][j]=='A' && i!=0 && board[i-1][j]!='B' && check)
            {
                board[i-1][j]=board[i][j];
                board[i][j]='.';
                check=false;

            }
        }
    }
}
void downMovement1(char** board,int n,int &s1)
{
    bool check=true;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) 
        {
            if(i!=n-1 && board[i+1][j]=='@' && board[i][j]=='A')
                s1+=10;
            else if(i!=n-1 && board[i+1][j]=='#' && board[i][j]=='A')
                s1+=10;
            else if(i!=n-1 && board[i+1][j]=='*' && board[i][j]=='A')
                s1+=10;

            if(board[i][j]=='A' && i!=n-1 && board[i+1][j]!='B' && check)
            {
                if((i!=n-1))
                {
                    board[i+1][j]=board[i][j];
                    board[i][j]='.';
                    check=false;
                }            
            }
            
        }
    }
}
void leftMovement1(char** board,int n,int &s1)
{
    bool check=true;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) 
        {
            if(j!=0 && board[i][j-1]=='@' && board[i][j]=='A')
                s1+=10;
            else if(j!=0 && board[i][j-1]=='#' && board[i][j]=='A')
                s1+=10;
            else if(j!=0 && board[i][j-1]=='*' && board[i][j]=='A')
                s1+=10;

            if(board[i][j]=='A' && j!=0 && board[i][j-1]!='B' && check)
            {
                if(j!=0)
                {
                    check=false;
                    board[i][j-1]=board[i][j];
                    board[i][j]='.';
                }
            }    
                
        }
    }
}
void rightMovement1(char** board,int n,int &s1)
{
    bool check=true;
    for (int i = 0; i < n; ++i) 
    {
        for (int j = 0; j < n; ++j) 
        {
            if(j!=n-1 && board[i][j+1]=='@' && board[i][j]=='A')
                s1+=10;
            else if(j!=n-1 && board[i][j+1]=='#' && board[i][j]=='A')
                s1+=10;
            else if(j!=n-1 && board[i][j+1]=='*' && board[i][j]=='A')
                s1+=10;

            if(board[i][j]=='A' && j!=n-1 && board[i][j+1]!='B' && check)
            {
                if(j!=n-1)
                {
                    check=false;
                    board[i][j+1]=board[i][j];
                    board[i][j]='.';
                }
            }            
        }
    }
}

void upMovement2(char** board,int n,int &s1)
{
    bool check=true;   
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) 
        {
            if(i!=0 && board[i-1][j]=='@' && board[i][j]=='B')
                s1+=10;
            else if(i!=0 && board[i-1][j]=='#' && board[i][j]=='B')
                s1+=10;
            else if(i!=0 && board[i-1][j]=='*' && board[i][j]=='B')
                s1+=10;

            if(board[i][j]=='B' && i!=0 && board[i-1][j]!='A' && check)
            {
                board[i-1][j]=board[i][j];
                board[i][j]='.';
                check=false;
            }
        }
    }
}
void downMovement2(char** board,int n,int &s1)
{
    bool check=true;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) 
        {
            if(i!=n-1 && board[i+1][j]=='@' && board[i][j]=='B')
                s1+=10;
            else if(i!=n-1 && board[i+1][j]=='#' && board[i][j]=='B')
                s1+=10;
            else if(i!=n-1 && board[i+1][j]=='*' && board[i][j]=='B')
                s1+=10;

            if(board[i][j]=='B' && i!=n-1 && board[i+1][j]!='A' && check) 
            {
                
                    board[i+1][j]=board[i][j];
                    board[i][j]='.';
                    check=false;
                        
            }

        }
    }
}
void leftMovement2(char** board,int n,int &s1)
{
    bool check=true;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) 
        {  
            if(j!=0 && board[i][j-1]=='@' && board[i][j]=='B')
                s1+=10;
            else if(j!=0 && board[i][j-1]=='#' && board[i][j]=='B')
                s1+=10;
            else if(j!=0 && board[i][j-1]=='*' && board[i][j]=='B')
                s1+=10;

            if(board[i][j]=='B' && j!=0 && board[i][j-1]!='A' && check)
            {
                if(j!=0)
                {
                    board[i][j-1]=board[i][j];
                    board[i][j]='.';
                    check=false;
                }
            }          
        }
    }
}
void rightMovement2(char** board,int n,int &s1)
{
    bool check=true;
    for (int i = 0; i < n; ++i) 
    {
        for (int j = 0; j < n; ++j) 
        { 
            if(j!=n-1 && board[i][j+1]=='@' && board[i][j]=='B')
                s1+=10;
            else if(j!=n-1 && board[i][j+1]=='#' && board[i][j]=='B')
                s1+=10;
            else if(j!=n-1 && board[i][j+1]=='*' && board[i][j]=='B')
                s1+=10;

            if(board[i][j]=='B' && j!=n-1 && board[i][j+1]!='A' && check)
            {
                if(j!=n-1)
                {
                    board[i][j+1]=board[i][j];
                    board[i][j]='.';
                    check=false;
                }
            }          
        }
    }
}


void displayBoard(char** board, int n,int &s1,int &s2) 
{
    
    cout<<"Player 'A' Score: "<<s1<<endl;
    cout<<"Player 'B' Score: "<<s2<<endl;
    int a=rand()%3;
    int x=rand()%n;
    int y=rand()%n;
   
    if(a==0 && board[x][y]!='A' && board[x][y]!='B') 
        board[x][y]='@';
    if(a==1 && board[x][y]!='B' && board[x][y]!='A')
        board[x][y]='#';
    if(a==2 && board[x][y]!='B' && board[x][y]!='A')
        board[x][y]='*';

    cout<<" ";
    for(int i=0;i<2*n+1;i++)
        cout<<"-";
    cout<<endl;
    for (int i = 0; i < n; ++i) 
    {
        cout<<"( " ;
        for (int j = 0; j < n; ++j) 
        {
            if(board[i][j]=='A')
                cout<<RED<<BLUE_BG<<board[i][j]<<RESET<<" ";
            else if(board[i][j]=='B')
                cout<<BLUE<<RED_BG<<board[i][j]<<RESET<<" ";
            else if(board[i][j]=='@')
                cout<<CYAN<<board[i][j]<<" "<<RESET;
            else if(board[i][j]=='#')
                cout<<GREEN<<board[i][j]<<" "<<RESET;
            else if(board[i][j]=='*')
                cout<<YELLOW<<board[i][j]<<" "<<RESET;
            else
                cout << board[i][j] << " ";
        }
        cout<<")" << endl;
    }
    cout<<" ";
    for(int i=0;i<2*n+1;i++)
        cout<<"-";
    cout<<endl<<endl;
}

void playerInput(int pipe_fd, char player) 
{
    string ch;
    cout << "Player " << player << " input (W,A,S,D): "<<endl;
    cin >> ch;
    ch += " ";
    write(pipe_fd, ch.c_str(), ch.length());
    close(pipe_fd);
}

void alarmHandler(int signum) {
    // Just exit the process upon receiving the alarm signal
    exit(0);
}

int main() 
{
    srand(time(NULL));
    //int n = 15; // Board size
    int rollNumber = 900; 
    
    int randomNumber = rand() % 90 + 10;
    int n = ((randomNumber * (rollNumber % randomNumber)) % 25) + 15;
    char** board = generateBoard(n);
    int score1=0;
    int score2=0;
    displayBoard(board, n,score1,score2);

    int pipe1_fd[2]; // Pipe for player 1
    int pipe2_fd[2]; // Pipe for player 2

    bool check = true;
    while (check) 
    {
        // Create pipes
        if (pipe(pipe1_fd) == -1 || pipe(pipe2_fd) == -1) 
        {
            cout<<"Pipe Failed";
            exit(EXIT_FAILURE);
        }

        pid_t p1 = fork();
        if (p1 == 0) 
        { 
            cout<<"----------Contols---------"<<endl;
            cout<<"Player 1 : W,A,S & D"<<endl;
            cout<<"Player 2 : I,J,K & L"<<endl;

            pid_t p2 = fork();
           
            if (p2 == 0)        //Player 1
            { 
                close(pipe1_fd[0]); 
                close(pipe2_fd[0]); 
                char ch;
               
                system("stty raw");
                read(STDIN_FILENO, &ch, 1);
                system("stty cooked");
            
                //cout<<endl<<"Player 2: ";
                
                write(pipe1_fd[1], &ch, sizeof(ch));
                close(pipe1_fd[1]);
                exit(0);
            } 
            else if (p2 > 0)    //player 2
            { 
                
                wait(NULL);
                
                close(pipe1_fd[0]); 
                close(pipe2_fd[0]); 
                char ch;

                system("stty raw");
                read(STDIN_FILENO, &ch, 1);
                system("stty cooked");

                write(pipe2_fd[1], &ch, sizeof(ch));
                close(pipe2_fd[1]);
                exit(0);
            } 
            else 
            {
                cout << "failed child" << endl;
                exit(EXIT_FAILURE);
            }
        } 
        else if (p1 > 0) 
        { // Parent process (Board Updator)
            wait(NULL);

            close(pipe1_fd[1]);
            close(pipe2_fd[1]);

            cout << "Board Updator: " << endl;
            //displayBoard(board, n);

            fd_set rfds;
            FD_ZERO(&rfds);
            FD_SET(pipe1_fd[0], &rfds);
            FD_SET(pipe2_fd[0], &rfds);

            struct timeval tv;
            tv.tv_sec = 2;
            tv.tv_usec = 0;

            bool player1Input = false;
            bool player2Input = false;

            int retval = select(FD_SETSIZE, &rfds, NULL, NULL, &tv);
            if (retval == -1) 
            {
                perror("select()");
            } 
            else if (retval) 
            {
                char buffer1[1024];
                char buffer2[1024];
                char bytes_read1;
                char bytes_read2;

                if (FD_ISSET(pipe1_fd[0], &rfds)) 
                {
                    bytes_read1 = read(pipe1_fd[0], buffer1, sizeof(buffer1));
                    buffer1[bytes_read1] = '\0';
                    player1Input = true;
                    char move;
                    move = buffer1[0];
                    switch (move) 
                    {
                        case 'w':
                            // Move w up (decrease row)
                            upMovement1(board,n,score1);
                            break;
                        case 'a':
                            // Move a left (decrease column)
                            leftMovement1(board,n,score1);
                            break;
                        case 's':
                            // Move s down (increase row)
                            downMovement1(board,n,score1);
                            break;
                        case 'd':
                            // Move d right (increase column)
                            rightMovement1(board,n,score1);
                            break;
                        default:
                            // Invalid move
                            break;
                    }
                }

                if (FD_ISSET(pipe2_fd[0], &rfds)) 
                {
                    bytes_read2 = read(pipe2_fd[0], buffer2, sizeof(buffer2));
                    buffer2[bytes_read2] = '\0';
                    player2Input = true;
                    char move;
                    move = buffer2[0];
                    switch (move) 
                    {
                        case 'i':
                            // Move w up (decrease row)
                            upMovement2(board,n,score2);
                            break;
                        case 'j':
                            // Move a left (decrease column)
                            leftMovement2(board,n,score2);
                            break;
                        case 'k':
                            // Move s down (increase row)
                            downMovement2(board,n,score2);
                            break;
                        case 'l':
                            // Move d right (increase column)
                            rightMovement2(board,n,score2);
                            break;
                        default:
                            // Invalid move
                            break;
                    }
                }
            } 
            else 
            {
                cout << "Time's up! No move from any player." << endl;
                //continue;
            }

            if (!player1Input) {
                cout << "Player 1 skipped its turn." << endl;
            }

            if (!player2Input) {
                cout << "Player 2 skipped its turn." << endl;
            }

            cout << "\033[2J\033[1;1H";
            displayBoard(board,n,score1,score2);

            
        } 
        else 
        {
            cout << "failed" << endl;
            exit(EXIT_FAILURE);
        }
        //std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }

    return 0;
}