#include <iostream>
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <cstring>
#include <unistd.h>

#define RESET   "\033[0m"       
#define BLACK   "\033[30m"      /* Black */
#define RED     "\033[31m"      /* Red */
#define GREEN   "\033[32m"      /* Green */
#define YELLOW  "\033[33m"      /* Yellow */
#define BLUE    "\033[34m"      /* Blue */
#define MAGENTA "\033[35m"      /* Magenta */
#define CYAN    "\033[36m"      /* Cyan */
#define WHITE   "\033[37m"      /* White */

#define BLACK_BG    "\033[40m"      /* Black background */
#define RED_BG      "\033[41m"      /* Red background */
#define GREEN_BG    "\033[42m"      /* Green background */
#define YELLOW_BG   "\033[43m"      /* Yellow background */
#define BLUE_BG     "\033[44m"      /* Blue background */
#define MAGENTA_BG  "\033[45m"      /* Magenta background */
#define CYAN_BG     "\033[46m"      /* Cyan background */
#define WHITE_BG    "\033[47m"      /* White background */

using namespace std;

struct Message {
    char sender[256];
    char message[256]; 
};

int main(int argc, char* argv[]) 
{
    if (argc != 2) {
        cerr << "Usage: " << argv[0] << " <client_index>" << endl;
        return 1;
    }

    int clientIndex = atoi(argv[1]);

    key_t key = ftok("group", clientIndex + 1);

    int shmid = shmget(key, sizeof(Message), 0666 | IPC_CREAT);

    if (shmid == -1) {
        perror("shmget");
        return 1;
    }

    Message *msg = (Message *)shmat(shmid, (void *)0, 0);

    cout <<BLUE<< "Private Chat ID - "<<RESET << clientIndex << endl;

    cout << "Write Data: ";
    cin.getline(msg->message, sizeof(msg->message));

    shmdt(msg);

    //shmctl(shmid, IPC_RMID, NULL);
    exit(0);
}
