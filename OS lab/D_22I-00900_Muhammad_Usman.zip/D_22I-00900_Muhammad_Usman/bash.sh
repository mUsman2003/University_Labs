#g++ -o main main.cpp 
#./main
#g++ -o server server.cpp
#./server
#g++ -o p1 p1.cpp
#g++ -o p2 p2.cpp
#./p1
g++ -o server server.cpp
g++ -o client client.cpp
./server