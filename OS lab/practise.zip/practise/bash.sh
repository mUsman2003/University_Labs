g++ -pthread -o main main1.cpp
./main