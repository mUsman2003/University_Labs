#include <iostream>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <string>
#include <sys/wait.h>

using namespace std;

struct Data
{
    int arr[1024];
};

int main()
{
    Data d1,d2;
    int Buff[1024];
    int fd1[2];

    pipe(fd1);

    pid_t pid=fork();
    if(pid==0)
    {
        cout<<"Child";
        close(fd1[0]);
        for(int n=0;n<5;n++)
            d1.arr[n]=n+1;
        write(fd1[1],&d1,sizeof(d1));
        cout<<"Writed"<<endl;
        exit(0);
    }
    else
    {
        wait(NULL);
        cout<<"Parent";
        close(fd1[1]);
        read(fd1[0],&d2,sizeof(Buff));
        for(int n=0;n<5;n++)
            cout<<d2.arr[n];
        cout<<"Readed"<<endl;
        exit(0);
    }

    return 0;
}